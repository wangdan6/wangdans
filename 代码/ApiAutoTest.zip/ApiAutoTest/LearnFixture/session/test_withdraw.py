class TestWithdraw:
    def test_case01(self, login):
        print("测试取现功能1")

    def test_case02(self, login):
        print("测试取现功能2")

    def test_case03(self, login):
        print("测试取现功能3")

    def test_case04(self, login):
        print("测试取现功能4")
