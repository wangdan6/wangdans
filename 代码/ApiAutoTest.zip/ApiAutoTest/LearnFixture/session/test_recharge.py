class TestRecharge:
    def test_case01(self, login):
        print("测试充值功能1")

    def test_case02(self, login, db):
        print("测试充值功能2")

    def test_case03(self, login):
        print("测试充值功能3")

    def test_case04(self, login):
        print("测试充值功能4")
